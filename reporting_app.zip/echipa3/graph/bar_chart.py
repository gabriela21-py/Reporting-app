import pandas as pd
from dash.dependencies import Output, Input
from plotly.graph_objs import Figure
from dash import dcc, html
import plotly.express as px

from graph.chart_interface import Chart

